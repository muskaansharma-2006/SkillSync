/* 
  CompetencyX - Core Application Logic & Interactions
*/

// Application State Store (Local Storage sync with fallback mock defaults)
const CompetencyState = {
  candidate: {
    name: "Muskaan",
    fullName: "Muskaan Sharma",
    avatar: "MS",
    overallScore: 84,
    level: "Intermediate",
    assessmentsCompleted: 6,
    skillsAssessed: 4,
    skills: {
      "Python": 87,
      "SQL": 82,
      "Problem Solving": 91,
      "Data Analysis": 84,
      "Communication": 76,
      "Debugging": 68
    },
    targets: {
      "Python": 90,
      "SQL": 85,
      "Debugging": 80,
      "Problem Solving": 95
    }
  },
  
  // Assessments List Data
  assessments: [
    {
      id: "python-practical",
      title: "Python Practical Competency",
      level: "Intermediate",
      duration: "30 mins",
      challenges: 8,
      progress: 37,
      status: "in-progress",
      score: null,
      category: "Programming",
      tags: ["Python", "Algorithms", "Debugging"]
    },
    {
      id: "sql-data-benchmark",
      title: "SQL & Data Analysis Benchmark",
      level: "Intermediate",
      duration: "25 mins",
      challenges: 6,
      progress: 100,
      status: "completed",
      score: 82,
      category: "Data",
      tags: ["SQL", "Analytics", "Joins"]
    },
    {
      id: "problem-solving-logic",
      title: "Problem Solving & Algorithmic Logic",
      level: "Advanced",
      duration: "35 mins",
      challenges: 5,
      progress: 0,
      status: "available",
      score: 91,
      category: "Core CS",
      tags: ["Data Structures", "Logic"]
    },
    {
      id: "realtime-api-backend",
      title: "Real-Time API & Backend Architecture",
      level: "Advanced",
      duration: "45 mins",
      challenges: 6,
      progress: 0,
      status: "available",
      score: null,
      category: "Backend",
      tags: ["REST", "Async", "Python"]
    },
    {
      id: "frontend-ui-benchmark",
      title: "Frontend UI/UX Practical Benchmark",
      level: "Intermediate",
      duration: "25 mins",
      challenges: 6,
      progress: 0,
      status: "available",
      score: null,
      category: "Frontend",
      tags: ["HTML", "CSS", "DOM"]
    }
  ],

  // Active Role State
  role: "candidate"
};

// Initialize Application on DOM Ready
document.addEventListener("DOMContentLoaded", () => {
  initNavigation();
  initRoleSwitcher();
  initMobileMenu();
  
  // Page-specific initializers
  const page = getPageName();
  if (page === "index" || page === "" || page === "index.html") {
    initCandidateDashboard();
  } else if (page === "assessments.html") {
    initAssessmentsPage();
  } else if (page === "assessment.html") {
    initPracticalAssessmentSimulation();
  } else if (page === "result.html") {
    initResultPage();
  } else if (page === "skill-gap.html") {
    initSkillGapPage();
  } else if (page === "passport.html") {
    initPassportPage();
  } else if (page === "recruiter.html") {
    initRecruiterDashboard();
  } else if (page === "candidate.html") {
    initCandidateProfileView();
  } else if (page === "history.html") {
    initHistoryPage();
  }
});

// Utility to parse current HTML filename
function getPageName() {
  const path = window.location.pathname;
  return path.substring(path.lastIndexOf('/') + 1);
}

// Navigation active state setup
function initNavigation() {
  const currentPage = getPageName() || "index.html";
  const navLinks = document.querySelectorAll(".nav-link");
  
  navLinks.forEach(link => {
    const href = link.getAttribute("href");
    if (href === currentPage || (currentPage === "" && href === "index.html")) {
      link.classList.add("active");
    } else {
      link.classList.remove("active");
    }
  });
}

// Candidate vs Recruiter Role Switcher
function initRoleSwitcher() {
  const candidateBtn = document.getElementById("role-candidate");
  const recruiterBtn = document.getElementById("role-recruiter");
  
  if (candidateBtn && recruiterBtn) {
    candidateBtn.addEventListener("click", () => {
      window.location.href = "index.html";
    });
    recruiterBtn.addEventListener("click", () => {
      window.location.href = "recruiter.html";
    });
  }
}

// Mobile Navbar Drawer
function initMobileMenu() {
  const btn = document.querySelector(".mobile-menu-btn");
  const links = document.querySelector(".nav-links");
  
  if (btn && links) {
    btn.addEventListener("click", () => {
      links.classList.toggle("active");
    });
  }
}

// Toast Notifications Helper
function showToast(message, type = "success") {
  let container = document.querySelector(".toast-container");
  if (!container) {
    container = document.createElement("div");
    container.className = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = "toast";
  const icon = type === "success" ? "fa-circle-check text-green" : "fa-circle-info text-primary";
  toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${message}</span>`;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ----------------------------------------------------
// PAGE-SPECIFIC IMPLEMENTATIONS
// ----------------------------------------------------

// 1. CANDIDATE DASHBOARD (index.html)
function initCandidateDashboard() {
  renderRadarChart("competencyRadarChart", [87, 82, 91, 84, 76]);
  renderTrendChart("competencyTrendChart");
}

// Render Radar Chart for Skills Breakdown
function renderRadarChart(canvasId, scores) {
  const ctx = document.getElementById(canvasId);
  if (!ctx || typeof Chart === 'undefined') return;

  new Chart(ctx, {
    type: 'radar',
    data: {
      labels: ['Python', 'SQL', 'Problem Solving', 'Data Analysis', 'Communication'],
      datasets: [{
        label: 'Current Competency %',
        data: scores,
        backgroundColor: 'rgba(99, 102, 241, 0.25)',
        borderColor: '#6366f1',
        pointBackgroundColor: '#06b6d4',
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: '#06b6d4',
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        r: {
          angleLines: { color: 'rgba(255, 255, 255, 0.1)' },
          grid: { color: 'rgba(255, 255, 255, 0.1)' },
          pointLabels: {
            color: '#94a3b8',
            font: { family: 'Plus Jakarta Sans', size: 12, weight: '600' }
          },
          ticks: {
            display: false,
            stepSize: 20
          },
          suggestedMin: 50,
          suggestedMax: 100
        }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });
}

// Render Trend Growth Line Chart
function renderTrendChart(canvasId) {
  const ctx = document.getElementById(canvasId);
  if (!ctx || typeof Chart === 'undefined') return;

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Current'],
      datasets: [{
        label: 'Overall Score',
        data: [68, 72, 75, 79, 81, 84],
        fill: true,
        backgroundColor: (context) => {
          const chart = context.chart;
          const {ctx, chartArea} = chart;
          if (!chartArea) return null;
          const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
          gradient.addColorStop(0, 'rgba(99, 102, 241, 0.01)');
          gradient.addColorStop(1, 'rgba(99, 102, 241, 0.3)');
          return gradient;
        },
        borderColor: '#6366f1',
        borderWidth: 3,
        tension: 0.4,
        pointRadius: 4,
        pointBackgroundColor: '#06b6d4'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          grid: { color: 'rgba(255, 255, 255, 0.05)' },
          ticks: { color: '#94a3b8' }
        },
        y: {
          grid: { color: 'rgba(255, 255, 255, 0.05)' },
          ticks: { color: '#94a3b8' },
          min: 60,
          max: 100
        }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });
}

// 2. ASSESSMENTS PAGE (assessments.html)
function initAssessmentsPage() {
  const searchInput = document.getElementById("assessmentSearch");
  const filterSelect = document.getElementById("categoryFilter");
  const cards = document.querySelectorAll(".assessment-card-item");

  function filterCards() {
    const query = searchInput ? searchInput.value.toLowerCase() : "";
    const category = filterSelect ? filterSelect.value.toLowerCase() : "all";

    cards.forEach(card => {
      const title = card.getAttribute("data-title").toLowerCase();
      const cardCategory = card.getAttribute("data-category").toLowerCase();

      const matchesSearch = title.includes(query);
      const matchesCategory = category === "all" || cardCategory === category;

      if (matchesSearch && matchesCategory) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  }

  if (searchInput) searchInput.addEventListener("input", filterCards);
  if (filterSelect) filterSelect.addEventListener("change", filterCards);
}

// 3. LIVE PRACTICAL ASSESSMENT SIMULATION (assessment.html)
function initPracticalAssessmentSimulation() {
  // Timer Countdown Logic (18:42 start time)
  let timeInSeconds = 18 * 60 + 42;
  const timerDisplay = document.getElementById("assessmentTimer");
  
  if (timerDisplay) {
    const timerInterval = setInterval(() => {
      if (timeInSeconds <= 0) {
        clearInterval(timerInterval);
        timerDisplay.textContent = "00:00";
        showToast("Time is up! Submitting assessment automatically...", "info");
        setTimeout(triggerSubmissionModal, 1500);
      } else {
        timeInSeconds--;
        const mins = Math.floor(timeInSeconds / 60);
        const secs = timeInSeconds % 60;
        timerDisplay.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
      }
    }, 1000);
  }

  // Interactive Code Execution Button
  const runCodeBtn = document.getElementById("runCodeBtn");
  const consoleOutput = document.getElementById("consoleOutput");
  const testResultsBadge = document.getElementById("testResultsBadge");

  if (runCodeBtn && consoleOutput) {
    runCodeBtn.addEventListener("click", () => {
      runCodeBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Running Tests...`;
      consoleOutput.innerHTML = `> Compiling Python 3.11 environment...<br>> Executing test_transaction_calculator.py...`;
      
      setTimeout(() => {
        runCodeBtn.innerHTML = `<i class="fa-solid fa-play"></i> Run Code`;
        consoleOutput.innerHTML = `> Running Test Case 1: calculate_tax([100, 250, 400], 0.15) ... PASS<br>> Running Test Case 2: handle_negative_balances([-50, 100]) ... PASS<br>> Running Test Case 3: zero_currency_division_check() ... PASS<br><br><span style="color: #10b981; font-weight: 600;">✓ All 3 Test Cases Passed cleanly (0.04s)</span>`;
        if (testResultsBadge) {
          testResultsBadge.className = "badge badge-green";
          testResultsBadge.innerHTML = `<i class="fa-solid fa-check"></i> 3/3 Passed`;
        }
        showToast("Code executed successfully! All test cases passed.", "success");
      }, 1200);
    });
  }

  // Submit Assessment Trigger
  const submitBtn = document.getElementById("submitAssessmentBtn");
  if (submitBtn) {
    submitBtn.addEventListener("click", () => {
      triggerSubmissionModal();
    });
  }
}

// Submission Loading Modal & Redirect
function triggerSubmissionModal() {
  const modal = document.getElementById("submissionModal");
  if (!modal) {
    window.location.href = "result.html";
    return;
  }
  
  modal.classList.add("active");
  const statusMsg = document.getElementById("modalStatusMsg");
  
  setTimeout(() => {
    if (statusMsg) statusMsg.textContent = "AI Evaluation in progress (Evaluating logic & complexity)...";
  }, 1200);

  setTimeout(() => {
    if (statusMsg) statusMsg.textContent = "Generating Competency Radar & Evidence Report...";
  }, 2400);

  setTimeout(() => {
    window.location.href = "result.html";
  }, 3600);
}

// 4. AI COMPETENCY RESULT (result.html)
function initResultPage() {
  renderRadarChart("resultRadarChart", [91, 87, 76, 82, 84]);
}

// 5. SKILL GAP ANALYSIS (skill-gap.html)
function initSkillGapPage() {
  // Add accordion click listeners for 4-week roadmap
  const roadmapItems = document.querySelectorAll(".roadmap-header");
  roadmapItems.forEach(item => {
    item.addEventListener("click", () => {
      const content = item.nextElementSibling;
      if (content) {
        const isHidden = content.style.display === "none";
        content.style.display = isHidden ? "block" : "none";
        const icon = item.querySelector(".toggle-icon");
        if (icon) {
          icon.className = isHidden ? "fa-solid fa-chevron-up toggle-icon" : "fa-solid fa-chevron-down toggle-icon";
        }
      }
    });
  });
}

// 6. PASSPORT PAGE (passport.html)
function initPassportPage() {
  const shareBtn = document.getElementById("sharePassportBtn");
  if (shareBtn) {
    shareBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(window.location.href);
      showToast("Public Passport link copied to clipboard!", "success");
    });
  }

  const exportBtn = document.getElementById("exportPassportBtn");
  if (exportBtn) {
    exportBtn.addEventListener("click", () => {
      showToast("Generating Verifiable Skill Credential PDF...", "info");
      setTimeout(() => {
        showToast("Competency Passport downloaded successfully!", "success");
      }, 1500);
    });
  }
}

// 7. RECRUITER DASHBOARD (recruiter.html)
function initRecruiterDashboard() {
  // Initialize Recruiter Pipeline Chart
  const ctx = document.getElementById("recruiterPipelineChart");
  if (ctx && typeof Chart !== 'undefined') {
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Applied', 'Screened', 'Practical Assessed', 'Strong Matches', 'Offers'],
        datasets: [{
          label: 'Candidates',
          data: [248, 142, 98, 64, 18],
          backgroundColor: [
            'rgba(99, 102, 241, 0.4)',
            'rgba(99, 102, 241, 0.6)',
            'rgba(6, 182, 212, 0.7)',
            'rgba(16, 185, 129, 0.85)',
            'rgba(139, 92, 246, 0.9)'
          ],
          borderRadius: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#94a3b8' } },
          y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#94a3b8' } }
        }
      }
    });
  }

  // Recruiter candidate filter table
  const searchInput = document.getElementById("candidateSearch");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      const term = e.target.value.toLowerCase();
      const rows = document.querySelectorAll(".candidate-row");
      rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(term) ? "" : "none";
      });
    });
  }
}

// 8. CANDIDATE PROFILE VIEW (candidate.html)
function initCandidateProfileView() {
  renderRadarChart("candidateMatchRadar", [87, 82, 91, 84, 76]);
}

// 9. HISTORY PAGE (history.html)
function initHistoryPage() {
  renderTrendChart("historyTrendChart");
}
